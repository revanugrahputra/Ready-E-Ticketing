<?php
$koneksi = mysqli_connect("localhost","root","","ka") or
die("gagal koneksi ke MySQL");
?>